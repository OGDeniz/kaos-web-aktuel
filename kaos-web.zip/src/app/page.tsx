import Image from "next/image";
import HomeLayout from "@/layouts/HomeLayout";
import ColorPreview from "@/components/ColorPreview";

export default function Page() {
  return (


    <HomeLayout />

  );

}
