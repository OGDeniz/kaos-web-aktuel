export default function LogoBlock() {
    return (
        <div className="text-4xl md:text-5xl font-extrabold tracking-tight text-left">
            LOGO <span className="text-secondary">❤️</span>
        </div>
    );
}
